print("Welcome to the Tip Calculator!")
totalBill = float(input("What was the total bill? $"))
tipPercentageInput = int(input("What percentage would you like to tip? 10, 12, 15? "))
numberOfPayers = int(input("How many people are splitting the bill? "))

tipPercentage = totalBill * (tipPercentageInput/100)
billPlusTip = float(totalBill + tipPercentage)
paymentPerPerson = float(billPlusTip/numberOfPayers)
print("Each person should pay: $" + str(round(paymentPerPerson, 2)))