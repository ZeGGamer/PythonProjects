#Step 1: Draw Starting Image
print('''

                                                   .       .
                                                    \     /
                                                 ._  '   '  _.
                                                   '  o@o  '
                                                     o@@@o
                                                 .-'  o@o  '-.
                                                     .   .
                                                    /     
                                                   .       .

                             'Xx  xX*,
                          ,*xXXx_xXx
                            _xXXXXXxx*,
                          ,*XXx@x@Xx
                            X @|@@ `x
                            '  ||    '
                               ||
                               ||
                               ||
                               ||
                            /ssssssss.
                      /sssssssSSSSssssssssss.
        /\         /sssssSSSSSSSSSSSSSSSssssssssssss.              Dani
~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~
 ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~

      ''')

print("Welcome to Treasure Island.\n Your mission is to find the treasure.\n You're at a cross road. Where do you want to go?")
#Step 2: Left or right
direction = str.lower(input("Type Left or Right: \n"))
if(direction == "left"):
    print("You follow the road and arrived at a river crossing")
elif(direction == "right"):
    print("You followed the road and got attacked by an troll.")
    print("GAME OVER!")
    exit()
else:
    print("ERROR, INCORRECT PROMPT")
    exit()

#Step 3: River. Wait or Swim
print("Do you wait for a boat, or do you try to swim across?")
riverDecision = str.lower(input("Type Wait or Swim: \n"))
if(riverDecision == "wait"):
    print("you waited for 100 years but a boat never came... \nGAME OVER")
    exit()
elif(riverDecision == "swim"):
    print("After a dangerous swim, you made it to the other side.")
else:
    print("ERROR, INCORRECT PROMPT")
    exit()

#Step 4: Red, Yellow, or Blue Door.
print("You've reached the end, but there are three doors. Which one do you enter?")
doorDecision = str.lower(input("Type Red, Yellow, or Blue: \n"))
if(doorDecision == "red"):
    print("Opened the Red door, and you were quickly engulfed in flames! \nGAME OVER")
    exit()
elif(doorDecision == "yellow"):
    print("You open the yellow door and find the treasure room!")
    print("YOU WIN!")
elif(doorDecision == "blue"):
    print("You opened the blue door, but you were bombarded by evil slimes! \nGAME OVER!")
    exit()
else:
    print("ERROR, INCORRECT PROMPT")
    exit()