#Hangman
import random

hangmanLogo= '''
------------------
WELCOME TO HANGMAN
------------------
'''

import hangmanArt
HangManStates = hangmanArt.HangManStates

print(hangmanLogo)
from hangmanWords import wordList
word = random.choice(wordList).lower()

wordGuessList = []
lettersGussed = []
for x in range(0, len(word)):
  wordGuessList += "_"

hangmanState = 6
#Game Loop

while (hangmanState > 0):
    print(wordGuessList)
    print(f"You've gussed these letters: {lettersGussed}")
    print(str(HangManStates[int(hangmanState)]))
    guess = str(input(f"Guess a letter: \n")).lower()

    if(guess in wordGuessList):
        print(f"You already guessed the letter {guess}.")
    elif (guess not in lettersGussed):
        lettersGussed.append(guess)

    print("")

    for x in range(len(word)):
        if(guess in word):
            if(word[x] == guess):
                wordGuessList[x] = guess
        else:
            hangmanState -= 1
            if(hangmanState >= 1):
                print(f"Too Bad, {guess} wasn't in the word")
            else:
                print(f"Too bad, Your word was {word}")
                print(str(HangManStates[int(hangmanState)]))
                print("GAME OVER!")
            break
    
    if("_" not in wordGuessList):
        print(f"{wordGuessList} \n \nCongradulations!")
        print(f"Your word was {word}! \n")
        print("Game Complete")
        break