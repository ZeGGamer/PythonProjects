print("The Love Calculator is calculating your score...")
name1 = input("What is your full name? ") # What is your name?
name2 = input("What is their full name? ") # What is their name?
# 🚨 Don't change the code above 👆
# Write your code below this line 👇

combinedNames = name1.lower() + name2.lower()

#Get Number of times TRUE occurs
t = combinedNames.count("t")
r = combinedNames.count("r")
u = combinedNames.count("u")
e = combinedNames.count("e")
numberTRUE = t + r + u + e

#Get Number of Times LOVE occurs
l = combinedNames.count("l")
o = combinedNames.count("o")
v = combinedNames.count("v")
numberFALSE = l + o + v + e

#Combine Numbers and Print
LoveScore = int(str(numberTRUE) + str(numberFALSE))
if(LoveScore < 10 or LoveScore > 90):
  print(f"Your score is {LoveScore}, you go together like coke and mentos.")
elif(40 <= LoveScore <= 50):
  print(f"Your score is {LoveScore}, you are alright together.")
else:
  print(f"Your score is {LoveScore}.")

