# Which year do you want to check?
year = int(input("What year do you want to check: "))

# Write your code below this line 👇
if(year % 4 == 0):
  #Step 1 Complete, Check the Except Case
  if(year % 100 == 0):
    #Not a Leap year, Unless
    if(year % 400 == 0):
      print("Leap year")
    else:
      print("Not leap year")
  else:
    print("Leap year")
else:
  print("Not leap year")