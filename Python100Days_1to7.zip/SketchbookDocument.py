# Sketchbook Document
import random
'''
https://app.auditorium.ai/courses/eelyNMYJKXeNJAbjssSEQz0m88XvnhX6
That link takes you to the auditorium link. We signed up for it with google with ggeffros@gmail.com

Do this for practice exercises

#Randomness
randomInt = random.randint(1, 10)
print(randomInt)

names = ['Angela', 'Ben', 'Jenny', 'Michael', 'Chloe']
randomListChoise = random.randint(0, len(names)-1)

print(f"{names[randomListChoise]} is going to buy the meal today!")

MyList = [[22, 14, 16], ["Joe", "Sam", "Abel"], [True, False, True]]
#printing a sublist
print(MyList[0])
[22, 14, 16]

# printing an element within a sublist
print(MyList[0][1]) #output: 14

# modifying an element in a sublist
MyList[0][1] = 20
print(MyList) #output:[[22, 20, 16], ["Joe", "Sam", "Abel"], [True, False, True]]



#Loops
numberToAdd = 2
sumAmmount = 0

for n in range(0, 2):
  if(n % 2 == 0 and n > 0):
    print(n)
    sumAmmount += numberToAdd
    numberToAdd += 2
    
print(sumAmmount)

'''

# Function

def printToTen():
    for x in range(1,11):
        print(x)

printToTen()